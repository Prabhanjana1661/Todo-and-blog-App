let posts = JSON.parse(localStorage.getItem("posts")) || [];

function savePosts() {
  localStorage.setItem("posts", JSON.stringify(posts));
}

function renderPosts() {
  const container = document.getElementById("posts-container");
  container.innerHTML = "";
  posts.slice().reverse().forEach((post, i) => {
    const div = document.createElement("div");
    div.className = "post";
    div.innerHTML = `
      <h3>${post.title}</h3>
      <p>${post.content}</p>
      <div class="post-actions">
        <button onclick="editPost(${posts.length - 1 - i})">Edit</button>
        <button onclick="deletePost(${posts.length - 1 - i})">Delete</button>
      </div>
    `;
    container.appendChild(div);
  });
}

function handleForm(event) {
  event.preventDefault();
  const title = document.getElementById("title").value.trim();
  const content = document.getElementById("content").value.trim();
  if (title && content) {
    posts.push({ title, content });
    savePosts();
    renderPosts();
    event.target.reset();
  }
}

function editPost(index) {
  const post = posts[index];
  document.getElementById("title").value = post.title;
  document.getElementById("content").value = post.content;
  deletePost(index);
}

function deletePost(index) {
  posts.splice(index, 1);
  savePosts();
  renderPosts();
}

document.getElementById("blog-form").addEventListener("submit", handleForm);
renderPosts();